package com.example.thebump_try1;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity {



    EditText email1;
    EditText name1;
    EditText username1;
    EditText pass1;
    EditText conpass1;
    EditText date1;
    Drawable ok;
    Drawable error;
    DatabaseHelper db;
    DatabaseHelper sqLiteHelper;
    SQLiteDatabase sqLiteDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        email1 = (EditText) findViewById(R.id.email);
        name1 = (EditText) findViewById(R.id.nameAdmin);
        pass1 = (EditText) findViewById(R.id.pass);
        conpass1 = (EditText) findViewById(R.id.conpass);
        username1 = (EditText) findViewById(R.id.user_name);
        date1 = (EditText) findViewById(R.id.dateOB);
        ok = getResources().getDrawable(R.drawable.ok);
        error = getResources().getDrawable(R.drawable.error);
        db = new DatabaseHelper(this);

        sqLiteHelper = new DatabaseHelper(this);

        Intent intent = getIntent();

    }

    public void signin(View view) {
        Intent intent=new Intent(this, SignIn.class);
        startActivity(intent);
    }



    public void signUp(View view) {

        String user=username1.getText().toString();
        String email=email1.getText().toString();
        String name=name1.getText().toString();
        String date=date1.getText().toString();
        String pass=pass1.getText().toString();
        String conpass=conpass1.getText().toString();
        if (user.isEmpty()||email.isEmpty()||name.isEmpty()||date.isEmpty()||pass.isEmpty()||conpass.isEmpty()){
            message("Error","Please fill all value",error);

        }
        else{
            if(pass.equals(conpass)){

                boolean  insert=db.insertdataU(sqLiteDatabase,user,pass,name,email,date);
                if(insert==true){
                    Intent intent = new Intent(this, SignIn.class);
                    startActivity(intent);

                    clearText();}
                else{
                    message("Error", "Record not added",error);
                }
            }
            else{
                message("Error","password and confirm password not compatible",error);
            }
        }

    }

    public void message(String titel, String message, Drawable icon){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setIcon(icon);
        builder.setCancelable(true);
        builder.setTitle(titel);
        builder.setMessage(message);
        builder.show();

    }

    public void clearText(){
        email1.setText("");
        name1.setText("");
        username1.setText("");
        pass1.setText("");
        conpass1.setText("");
        date1.setText("");
        email1.setFocusable(true);

    }





}
