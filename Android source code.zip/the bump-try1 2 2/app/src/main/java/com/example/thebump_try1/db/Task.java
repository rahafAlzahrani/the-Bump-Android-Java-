package com.example.thebump_try1.db;

import android.provider.BaseColumns;

public class Task {

    public static final String DB_NAME="com.example.todo.db";
    public static final int DB_VERSION=1;

    public class taskEntry implements BaseColumns {
        public static final String TABLE="appointments";
        public static final String COL_TASK_TITLE="title";
    }
}
