package com.example.thebump_try1;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class SignIn extends AppCompatActivity {
    EditText email1;
    EditText pass1;
    Drawable ok;
    Drawable error;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        db = new DatabaseHelper(this);
        email1 = (EditText) findViewById(R.id.email);
        pass1 = (EditText) findViewById(R.id.pass);
        ok = getResources().getDrawable(R.drawable.ok);
        error = getResources().getDrawable(R.drawable.error);

    }

    public void register(View view) {
        Intent intent=new Intent(this,SignUp.class);
        startActivity(intent);
    }

    public void logIn(View view) {

        String  email=email1.getText().toString();
        String  pass=pass1.getText().toString();

        if(email.isEmpty()|| pass.isEmpty()){

            message("Error","Please fill all value",error);
        }
        else{
            Cursor c=db.signIn(email,pass);


            if(c.getCount() > 0) {



                message("Success", "Logged IN", ok);
               // the account page here



                if(email1.getText().toString().equals("a@hotmail.com")){
                    Intent intent = new Intent(this, AdminAccount.class);
                    intent.putExtra("email", email);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(this, account.class);
                    intent.putExtra("email", email);
                    startActivity(intent);
                }






            }
            else{
                message("Error","Please check the email or password",error);
            }
        }
    }



    public void message(String titel, String message, Drawable icon){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(titel);
        builder.setMessage(message);
        builder.show();

    }

}
