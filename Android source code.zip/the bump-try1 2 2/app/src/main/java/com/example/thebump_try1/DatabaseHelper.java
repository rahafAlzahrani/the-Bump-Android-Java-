
package com.example.thebump_try1;

import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.example.thebump_try1.db.Task;
import java.time.LocalDate;

import java.time.Month;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "TheBump";
    private static final int DATABASE_VERSION = 5;

    //tables name
    public static final String COMMUNITY_TABLE = "Community";
    public static final String QUESTIONS_TABLE = "Questions";
    public static final String QUESTIONS_Column = "question";
    public static final String USER_TABLE = "user";
    public static final String table_name = "user";
    public static final String username = "username";
    public static final String pass = "pass";
    public static final String name = "name";
    public static final String emaill = "emaill";
    public static final String date = "date";
    public static final String appointments= "appointments";
    //create table statement

    static final String CREATE_COMMUNITY_TABLE = "CREATE TABLE Community(question TEXT,answer TEXT);";
    static final String CREATE_QUESTIONS_TABLE = "CREATE TABLE Questions(question TEXT);";
    static final String CREATE_User_TABLE = "CREATE TABLE user (username TEXT PRIMARY KEY ,pass TEXT, name TEXT , emaill TEXT, date TEXT);";
    static final  String CREATE_APPOINTMENT_TABLE ="CREATE TABLE "+ Task.taskEntry.TABLE + "("+
            Task.taskEntry._ID +" INTEGER PRIMARY KEY AUTOINCREMENT ,"+
            Task.taskEntry.COL_TASK_TITLE+ "  TEXT NOT NULL);";

    public DatabaseHelper(Context context) { super(context, DATABASE_NAME, null, DATABASE_VERSION); }


    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_COMMUNITY_TABLE);
        db.execSQL(CREATE_QUESTIONS_TABLE);
        db.execSQL(CREATE_User_TABLE);
        db.execSQL(CREATE_APPOINTMENT_TABLE);

        db.execSQL("INSERT INTO " + USER_TABLE + " VALUES('admin','123','Muneera','a@hotmail.com','2020-05-31');");
        db.execSQL("INSERT INTO " + USER_TABLE + " VALUES('user','123','Khawlah','user@hotmail.com','2020-01-31');");

        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('What effect does coronavirus have on pregnant women?', 'It is expected the large majority of pregnant women will experience only mild or moderate cold/flu like symptoms.');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('Can I still practice sport when I’m pregnant?', 'You certainly can, although not everything is still possible or sensible. Just ask us at your next consultation.');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('What is a hard belly? ', ' With a hard belly the uterus contracts. The uterus is a muscle that contracts throughout the pregnancy. Usually this is not serious and is just a bit annoying.');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('When will I feel the baby move for the first time? ', ' You usually feel your baby move for the first time between 18 and 22 weeks. This may happen earlier if you have been pregnant before. If you don’t feel the baby halfway through the pregnancy, don’t be alarmed straight away. ');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('How much weight will I gain during my pregnancy?', 'how much cannot be determined beforehand. It is however very important to make sure that you don’t gain too much. What may be considered a normal weight increase for you depends on a number of factors. ');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('I’d like to lose weight, can I do that when I’m pregnant?', 'It is better for you and your baby to not diet during a pregnancy. However, if you were already overweight before becoming pregnant, it would be wise to monitor your weight. ');");
        db.execSQL("INSERT INTO " + COMMUNITY_TABLE + " VALUES('Can I still visit the sauna?', 'You can visit the sauna during your pregnancy, but do take into account that you may not be able to withstand heat as well as before. It is therefore wise to not stay too long or get too hot and to avoid alternating baths. ');");

        db.execSQL("INSERT INTO " + QUESTIONS_TABLE + " VALUES('What are the early signs of pregnancy?');");
        db.execSQL("INSERT INTO " + QUESTIONS_TABLE + " VALUES('Is it possible to be pregnant and not know it?');");
        db.execSQL("INSERT INTO " + QUESTIONS_TABLE + " VALUES('Is it really that dangerous to get pregnant after 35?');");


    }

    public Cursor signIn(String email2, String pass2) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM '" + USER_TABLE + "'where pass=? and emaill=?", new String[]{pass2, email2});

        return res;
    }
    public boolean insertdataU(SQLiteDatabase db, String password, String uname, String Username, String Uemaill, String Date) {

        String sql = "INSERT INTO user (username,pass,name,emaill,date) VALUES (?,?,?,?,?)";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, Username);
        statement.bindString(2, password);
        statement.bindString(3, uname);
        statement.bindString(4, Uemaill);
        statement.bindString(5, Date);
        statement.execute();

            return true;

    }

    public static void insertQuestion(String question, SQLiteDatabase db) {

        String sql = "INSERT INTO Questions (question) VALUES (?)";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, question);
        statement.execute();
    }

    public static void insertAnswerdQuestion (String ques, String ans, SQLiteDatabase db) {

        String sql = "INSERT INTO Community (question,answer) VALUES (?,?)";
        SQLiteStatement statement = db.compileStatement(sql);
        statement.bindString(1, ques);
        statement.bindString(2, ans);
        statement.execute();
    }

    public static void deleteAnswerdQuestion(String quest, SQLiteDatabase db) {

        String deleteQuestion = "delete from Questions where question = '"+ quest +"'";
        db.execSQL(deleteQuestion);


        //db.delete(QUESTIONS_TABLE, QUESTIONS_Column + "=" + quest, null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Community");
        db.execSQL("DROP TABLE IF EXISTS Questions");
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS appointments");

        onCreate(db);
    }
    public Cursor userProfileInfo(String e) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select username,pass,name,date from '" + USER_TABLE + "' where emaill= ? ",new String[]{e});
    }
    public Cursor adminProfileInfo(String e) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select username,pass,name from '" + USER_TABLE + "' where emaill= ? ",new String[]{e});
    }
    public long updateUserName(String Email, String name)
    {
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        SQLiteDatabase db = this.getWritableDatabase();
        return db.update("user",cv,"emaill="+ "'" + Email + "'" ,  null );
    }
    public long updateUserDate(String Email, String date)
    {
        ContentValues cv = new ContentValues();
        cv.put("date",date);
        SQLiteDatabase db = this.getWritableDatabase();
        return db.update("user",cv,"emaill="+ "'" + Email + "'" ,  null );
    }
    public long updateUserPass(String Email, String pass)
    {
        ContentValues cv = new ContentValues();
        cv.put("pass",pass);
        SQLiteDatabase db = this.getWritableDatabase();
        return db.update("user",cv,"emaill="+ "'" + Email + "'" ,  null );
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public int cutMonth(String s) {

        LocalDate currentdate = LocalDate.now();
        int currentMonth = currentdate.getMonthValue();
        int currentStr = Integer.parseInt(s.substring(s.indexOf("-") + 1, s.lastIndexOf("-")));
        int result = currentMonth - currentStr;

        return result;


    }

    public Cursor getDate(String email) {

        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select date from '" + USER_TABLE + "' where emaill= ? ",new String[]{email});


    }

}
