package com.example.thebump_try1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminAccount extends AppCompatActivity {


    TextView name;
    TextView usertype;
    TextView pas;
    Bundle bundle;
    String email;
    Cursor result;
    DatabaseHelper helper ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_account);
        Intent i = getIntent();
        bundle = i.getExtras();
        email = bundle.getString("email");
        helper = new DatabaseHelper(this);
        result=helper.adminProfileInfo(email);
        name=(TextView) findViewById(R.id.nameAdmin);
        usertype=(TextView) findViewById(R.id.type);
        pas=(TextView) findViewById(R.id.pasA);
        if (result.getCount() == 0) {
            Toast.makeText(this, "No Match", Toast.LENGTH_LONG).show();
        } else {
            result.moveToFirst();
            String u = result.getString(0);
            String p = result.getString(1);
            String n = result.getString(2);
            name.setText(n);
            pas.setText(p);
            usertype.setText(u);
        }
    }
    public void UpdateInfo(View view) {
        Intent intent = new Intent(this, editAdmin.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }
    public void AnswerQuestion(View view) {
        Intent intent1 = new Intent(this, QA_CommunityAdmin.class);
        startActivity(intent1);
    }

    public void signOutFunc(View view) {

        Intent intent = new Intent(this, SignIn.class);
        startActivity(intent);

    }
}
