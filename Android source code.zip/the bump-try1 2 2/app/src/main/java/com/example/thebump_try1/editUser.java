
package com.example.thebump_try1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class editUser extends AppCompatActivity {
    EditText name;
    EditText password;
    EditText date;
    String namea;
    String passworda;
    String datea;
    Bundle bundle;
    String email, email2;
    DatabaseHelper helper ;
    Cursor result;
    String d;
    long feedbackname;
    long feedbackpass;
    long feedbackdate;
    Button home, community, appointments, account;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);
        Intent i = getIntent();
        bundle = i.getExtras();
        email = bundle.getString("email");
        helper = new DatabaseHelper(this);
        result=helper.userProfileInfo(email);
        name = findViewById(R.id.nameedit);
        password = findViewById(R.id.pasedit);
        date = findViewById(R.id.duedateedit);
        home=(Button)findViewById(R.id.home);
        community=(Button)findViewById(R.id.community);
        appointments=(Button)findViewById(R.id.appointment);
        account=(Button)findViewById(R.id.account);

        if (result.getCount() == 0) {
            Toast.makeText(this, "No Match", Toast.LENGTH_LONG).show();
        } else {
            result.moveToFirst();
            d = result.getString(3);

        }

        Intent intent= getIntent();
        email2 = intent.getStringExtra("email");

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                i.putExtra("email", email2);
                //send due date
                i.putExtra("due",d);
                startActivity(i);
            }
        });

        community.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), QA_Community.class);
                i.putExtra("email", email2);
                startActivity(i);
            }
        });
        appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), appointment.class);
                i.putExtra("email", email2);
                startActivity(i);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), account.class);
                i.putExtra("email", email2);
                startActivity(i);
            }
        });
    }

    public static boolean isName(String s) {
        return s.matches("[A-Za-z]*");
    }

    public void onClickEditUser(View v){
        namea = name.getText().toString().trim();
        passworda = password.getText().toString().trim();
        datea = date.getText().toString().trim();

        if(namea.length()>0)
            if(isName(namea)){
            feedbackname=helper.updateUserName(email,namea);
            }else {
                Message("Error", "Make sure the name is in name format");
            }
        if(passworda.length()>0)
            feedbackpass=helper.updateUserPass(email,passworda);
        if(datea.length()>0){
            if(!isValid(date.getText().toString())){
                Message("Error", "Make sure the date must be in (yyyy-mm-dd) format");
                date.requestFocus();
                return;
            }
            feedbackdate=helper.updateUserDate(email,datea);
        }
        if(feedbackname!=0 || feedbackpass!=0  || feedbackdate!=0){
            Toast.makeText(this, "Your info has been updated successfully.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, account.class);
            intent.putExtra("email", email);
            startActivity(intent);
        }
        else {
            Toast.makeText(this, "Sorry! something went wrong", Toast.LENGTH_LONG).show();

        }

    }
    public void Message(String title, String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    // source https://stackoverflow.com/questions/2149680/regex-date-format-validation-on-java
    public static boolean isValid(String text) {
        if (text == null || !text.matches("\\d{4}-[01]\\d-[0-3]\\d"))
            return false;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        df.setLenient(false);
        try {
            df.parse(text);
            return true;
        } catch (ParseException ex) {
            return false;
        }
    }
}
