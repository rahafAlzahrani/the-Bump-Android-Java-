package com.example.thebump_try1;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class QA_Community extends AppCompatActivity {

    DatabaseHelper sqLiteHelper;
    SQLiteDatabase sqLiteDatabase;
    Cursor cursor;
    String d;
    Cursor cursor2;

    communityListAdapter listAdapter;
    ListView LISTVIEW;
    EditText questionArea;
    Button ask;
    ArrayList<String> question;
    ArrayList<String> answer;
    Button home, community, appointments, account;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.q_a_community);

        sqLiteHelper = new DatabaseHelper(this);


        question = new ArrayList<>();
        answer = new ArrayList<>();
        LISTVIEW = findViewById(R.id.listMenu);
        questionArea = findViewById(R.id.editText);
        ask = findViewById(R.id.button);
        home=(Button)findViewById(R.id.home);
        community=(Button)findViewById(R.id.community);
        appointments=(Button)findViewById(R.id.appointment);
        account=(Button)findViewById(R.id.account);

        Intent i=getIntent();
        email=i.getStringExtra("email");

        cursor2=sqLiteHelper.userProfileInfo(email);

        if (cursor2.getCount() == 0) {
            Toast.makeText(this, "No Match", Toast.LENGTH_LONG).show();
        } else {
            cursor2.moveToFirst();

            d = cursor2.getString(3);

        }

        questionArea.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == 66) {
                    hideKeyboard(v);
                    return true; //this is required to stop sending key event to parent
                }
                return false;
            }
        });
        questionArea.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {
                    LISTVIEW.setVisibility(View.INVISIBLE);
                } else {
                }
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                i.putExtra("email", email);
                //send due date
                i.putExtra("due",d);
                startActivity(i);
            }
        });

        community.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), QA_Community.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), appointment.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), account.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });

    }

    private void hideKeyboard(View view) {
        InputMethodManager manager = (InputMethodManager) view.getContext().getSystemService(INPUT_METHOD_SERVICE);
        if (manager != null) {
            manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            LISTVIEW.setVisibility(View.VISIBLE);
            ShowSQLiteDBdata() ;
            questionArea.setFocusable(true);
        }

    }

    @Override
    protected void onResume() {

        ShowSQLiteDBdata() ;
        super.onResume();
    }

    private void ShowSQLiteDBdata() {

        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        cursor = sqLiteDatabase.query(DatabaseHelper.COMMUNITY_TABLE,null,null, null,null,null,null);

        question.clear();
        answer.clear();

        cursor.moveToFirst();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                question.add(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(0))));
                answer.add(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(1))));

            } while (cursor.moveToNext());
        }

        listAdapter = new communityListAdapter(QA_Community.this,question,answer);
        LISTVIEW.setAdapter(listAdapter);
        cursor.close();
    }


    public void askQuestion(View view) {
        String questionAsked = questionArea.getText().toString().trim();

        if (questionAsked.length() > 0) {
            DatabaseHelper.insertQuestion(questionAsked + "?", sqLiteDatabase);
            showMessage("success","your question will be answerd within 1 day, thank you." );
            questionArea.setText("");
        }
        else if(questionAsked.length() == 0){
            Toast.makeText(QA_Community.this, "please ask a question before click the button.", Toast.LENGTH_LONG).show();
        }
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }



}
