package com.example.thebump_try1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class communityAdminListAdapter extends BaseAdapter{

    Context context;
    ArrayList<String> question1;


    public communityAdminListAdapter(Context context2, ArrayList<String> question1) {

        this.context = context2;
        this.question1 = question1;
    }

    public int getCount() { return question1.size(); }
    public Object getItem(int position) { return null; }
    public long getItemId(int position) { return 0; }

    public View getView(int position, View child, ViewGroup parent) {

        Holder holder;
        LayoutInflater layoutInflater;

        if (child == null) {
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.single_question, null);

            holder = new Holder();
            holder.Question_TextView = child.findViewById(R.id.askedQuestion);

            child.setTag(holder);

        } else {

            holder = (Holder) child.getTag();
        }

        holder.Question_TextView.setText(question1.get(position));

        return child;
    }


    public class Holder {
        TextView Question_TextView;
    }

}
