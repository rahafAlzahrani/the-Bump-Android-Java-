package com.example.thebump_try1;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class home extends AppCompatActivity {

    DatabaseHelper helper ;

    int currentMonth = 0;

    String date;

    ImageView monthTitle;
    ImageView monthPicture;
    TextView babySizeDescription;
    ImageView babySizePicture;
    TextView newFactsDescription;
    Button home, community, appointments, account;
    String email;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        helper = new DatabaseHelper(this);

        Intent i = getIntent();
        date = i.getStringExtra("due");

        currentMonth = helper.cutMonth(date);


        System.out.println("date : " + date + "current : " + currentMonth);

        monthTitle = findViewById(R.id.currentMonth);
        monthPicture = findViewById(R.id.monthPic);
        babySizeDescription = findViewById(R.id.babySizeDesc);
        babySizePicture = findViewById(R.id.babySizePic);
        newFactsDescription = findViewById(R.id.newFactsDesc);
        home=(Button)findViewById(R.id.home);
        community=(Button)findViewById(R.id.community);
        appointments=(Button)findViewById(R.id.appointment);
        account=(Button)findViewById(R.id.account);
        Intent intent= getIntent();
        email = intent.getStringExtra("email");

        String m1babySize = "By the end of this month, the baby is the size of a grain of rice!";
        String m2babySize = "By the end of this month, the baby is the size of a cherry!";
        String m3babySize = "By the end of this month, the baby is the size of a lemon!";
        String m4babySize = "By the end of this month, the baby is the size of a pear!";
        String m5babySize = "By the end of this month, the baby is the size of a grapefruit!";
        String m6babySize = "By the end of this month, the baby is the size of an eggplant!";
        String m7babySize = "By the end of this month, the baby is the size of a pineapple!";
        String m8babySize = "By the end of this month, the baby is the size of a papaya!";
        String m9babySize = "By the end of this month, the baby is the size of a watermelon!";

        String m1facts = "Your baby is only .1 to .2 millimeters and at this stage is called a blastocyst. At three weeks pregnant, your child has already developed all his genetic material – and the sex is already decided.";
        String m2facts = "Your baby is now a little under an inch long but has developed into a tiny human being. The heart is beating, the brain is developing and she has developed all her limbs as well as hands and feet.";
        String m3facts = "Your baby is now officially a fetus and is between two and four inches long. By the end of the first trimester, all organs are present, and even fingernails are developing. Your baby is also moving her arms and legs, though you won’t feel it yet.";
        String m4facts = "Your baby is five to six inches long and weighs up to four ounces. Baby’s face and heart are fully formed at this point, though the lungs are still developing. Baby’s eyes will open during this month and he or she will begin feeling the urge to suck.";
        String m5facts = "Your baby is now about 10 ounces and six to nine inches long. Baby is covered with a fine protective hair. This month he or she will develop fingerprints and permanent teeth buds behind fully formed baby teeth. Sex can be determined via an ultrasound.";
        String m6facts = "Your baby is about 10 inches long and weighs over a pound. You’ll be aware of baby’s movements as he or she stretches and hiccups. Baby’s eyes now open and close, vocal cords are functioning.";
        String m7facts = "Your baby is starting to develop fat under his or her skin. Baby’s now almost 12 inches long and weighs between two and four pounds. Your child can now see, hear and taste, and the brain and nervous system are growing rapidly.";
        String m8facts = "Your baby is starting to develop fat under his or her skin. Baby’s now almost 12 inches long and weighs between two and four pounds. Your child can now see, hear and taste, and the brain and nervous system are growing rapidly.";
        String m9facts = "Baby’s lungs are maturing, and he or she is shedding the layer of hair that protected him or her in the uterus. Your baby’s brain is growing tremendously this last month. Baby measures about 18 to 21 inches long and weighs about six to eight pounds.";

        if(currentMonth == 1) {

            monthTitle.setImageResource(R.drawable.month1);
            monthPicture.setImageResource(R.drawable.m1);
            babySizeDescription.setText(m1babySize);
            babySizePicture.setImageResource(R.drawable.wheat);
            newFactsDescription.setText(m1facts);

        }

        else if(currentMonth == 2) {

            monthTitle.setImageResource(R.drawable.month2);
            monthPicture.setImageResource(R.drawable.m2);
            babySizeDescription.setText(m2babySize);
            babySizePicture.setImageResource(R.drawable.cherry);
            newFactsDescription.setText(m2facts);

        }

        else if(currentMonth == 3) {

            monthTitle.setImageResource(R.drawable.month3);
            monthPicture.setImageResource(R.drawable.m3);
            babySizeDescription.setText(m3babySize);
            babySizePicture.setImageResource(R.drawable.lemon);
            newFactsDescription.setText(m3facts);

        }

        else if(currentMonth == 4) {

            monthTitle.setImageResource(R.drawable.month4);
            monthPicture.setImageResource(R.drawable.m4);
            babySizeDescription.setText(m4babySize);
            babySizePicture.setImageResource(R.drawable.pear);
            newFactsDescription.setText(m4facts);

        }

        else if(currentMonth == 5) {

            monthTitle.setImageResource(R.drawable.month5);
            monthPicture.setImageResource(R.drawable.m5);
            babySizeDescription.setText(m5babySize);
            babySizePicture.setImageResource(R.drawable.grapefruit);
            newFactsDescription.setText(m5facts);

        }

        else if(currentMonth == 6) {

            monthTitle.setImageResource(R.drawable.month6);
            monthPicture.setImageResource(R.drawable.m6);
            babySizeDescription.setText(m6babySize);
            babySizePicture.setImageResource(R.drawable.eggplant);
            newFactsDescription.setText(m6facts);

        }

        else if(currentMonth == 7) {

            monthTitle.setImageResource(R.drawable.month7);
            monthPicture.setImageResource(R.drawable.m7);
            babySizeDescription.setText(m7babySize);
            babySizePicture.setImageResource(R.drawable.pineapple);
            newFactsDescription.setText(m7facts);

        }

        else if(currentMonth == 8) {

            monthTitle.setImageResource(R.drawable.month8);
            monthPicture.setImageResource(R.drawable.m8);
            babySizeDescription.setText(m8babySize);
            babySizePicture.setImageResource(R.drawable.papaya);
            newFactsDescription.setText(m8facts);

        }

        else if(currentMonth == 9) {

            monthTitle.setImageResource(R.drawable.month9);
            monthPicture.setImageResource(R.drawable.m9);
            babySizeDescription.setText(m9babySize);
            babySizePicture.setImageResource(R.drawable.watermelon);
            newFactsDescription.setText(m9facts);

        }

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });

        community.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), QA_Community.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), appointment.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), account.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });

    }
}
