package com.example.thebump_try1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class account extends AppCompatActivity {


    TextView name;
    TextView due;
    TextView usertype;
    TextView pas;
    Bundle bundle;
    String email, d;
    Cursor result;
    DatabaseHelper helper ;
    Button home, community, appointments, account;
    Button signout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        Intent i = getIntent();
        email = i.getStringExtra("email");
        helper = new DatabaseHelper(this);
        result=helper.userProfileInfo(email);
        name=(TextView) findViewById(R.id.name);
        usertype=(TextView) findViewById(R.id.userType);
        pas=(TextView) findViewById(R.id.pas);
        due=(TextView) findViewById(R.id.duedate);
        home=(Button)findViewById(R.id.home);
        community=(Button)findViewById(R.id.community);
        appointments=(Button)findViewById(R.id.appointment);
        account=(Button)findViewById(R.id.account);

        if (result.getCount() == 0) {
            Toast.makeText(this, "No Match", Toast.LENGTH_LONG).show();
        } else {
            result.moveToFirst();
            String u = result.getString(0);
            String p = result.getString(1);
            String n = result.getString(2);
             d = result.getString(3);
            name.setText(n);
            due.setText(d);
            pas.setText(p);
            usertype.setText(u);
        }

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                i.putExtra("email", email);
                //send due date
                i.putExtra("due",d);
                startActivity(i);
            }
        });

        community.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), QA_Community.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), appointment.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), account.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
    }
    public void UpdateInfo(View view) {
        Intent intent = new Intent(this, editUser.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }

    public void signOutFunc(View view) {

        Intent intent = new Intent(this, SignIn.class);
        startActivity(intent);

    }


}
