package com.example.thebump_try1;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class QA_CommunityAdmin extends AppCompatActivity {

    DatabaseHelper sqLiteHelper;
    SQLiteDatabase sqLiteDatabase;
    Cursor cursor;
    communityAdminListAdapter listAdapter;
    ListView LISTVIEW;
    TextView Ques;
    EditText answerArea;
    Button answer;
    ArrayList<String> question;
    String quest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.q_a_community_admin);

        sqLiteHelper = new DatabaseHelper(this);
        question = new ArrayList<>();
        LISTVIEW = findViewById(R.id.listMenu);
        answerArea = findViewById(R.id.editText);
        answer = findViewById(R.id.button);
        Ques = findViewById(R.id.theQuestion);

        LISTVIEW.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                quest = question.get(position).trim();
                Ques.setText(quest);


            }
        });

        answerArea.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == 66) {
                    hideKeyboard(v);
                    return true; //this is required to stop sending key event to parent
                }
                return false;
            }
        });
        answerArea.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {
                    LISTVIEW.setVisibility(View.INVISIBLE);
                } else {
                }
            }
        });

    }

    private void hideKeyboard(View view) {
        InputMethodManager manager = (InputMethodManager) view.getContext().getSystemService(INPUT_METHOD_SERVICE);
        if (manager != null) {
            manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            LISTVIEW.setVisibility(View.VISIBLE);
            ShowSQLiteDBdata() ;
            answerArea.setFocusable(true);
        }

    }

    @Override
    protected void onResume() {

        ShowSQLiteDBdata() ;
        super.onResume();
    }

    private void ShowSQLiteDBdata() {

        sqLiteDatabase = sqLiteHelper.getWritableDatabase();
        cursor = sqLiteDatabase.query(DatabaseHelper.QUESTIONS_TABLE,null,null, null,null,null,null);

        question.clear();

        cursor.moveToFirst();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                question.add(cursor.getString(cursor.getColumnIndex(cursor.getColumnName(0))));
            } while (cursor.moveToNext());
        }

        listAdapter = new communityAdminListAdapter(QA_CommunityAdmin.this,question);
        LISTVIEW.setAdapter(listAdapter);
        cursor.close();
    }


    public void backToAccount(View view) {
        Intent intent1 = new Intent(this, AdminAccount.class);
        startActivity(intent1);
    }

    public void answerQuestion(View view) {
        if (Ques.getText().toString().trim().equals("question") || Ques.getText().toString().trim().equals("")) {
            Toast.makeText(QA_CommunityAdmin.this, "please choose a question before click the button.", Toast.LENGTH_LONG).show();
        } else {
            String questionAnswered = answerArea.getText().toString().trim();

            if (questionAnswered.length() > 0) {
                DatabaseHelper.insertAnswerdQuestion(quest, questionAnswered, sqLiteDatabase);
                DatabaseHelper.deleteAnswerdQuestion(quest, sqLiteDatabase);
                showMessage("success", "your answer will be added to the questions community, thank you.");
                ShowSQLiteDBdata();
                answerArea.setText("");
                quest = "";
            } else if (questionAnswered.length() == 0) {
                Toast.makeText(QA_CommunityAdmin.this, "please answer the question before click the button.", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}
