package com.example.thebump_try1;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.thebump_try1.db.Task;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class appointment extends AppCompatActivity {

    private static final String TAG="MainActivity";
    private DatabaseHelper taskHelper;
    private ListView TaskListView;
    private ArrayAdapter<String> mAdapter;
    Button home, community, appointments, account;
    String  email;
    Cursor result;
    DatabaseHelper helper ;
    String d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        home=(Button)findViewById(R.id.home);
        community=(Button)findViewById(R.id.community);
        appointments=(Button)findViewById(R.id.appointment);
        account=(Button)findViewById(R.id.account);
        taskHelper=new DatabaseHelper(this);
        TaskListView=(ListView)findViewById(R.id.list_todo);
        Intent i= getIntent();
         email = i.getStringExtra("email");
        updateUI();
        helper = new DatabaseHelper(this);
        result=helper.userProfileInfo(email);

        if (result.getCount() == 0) {
            Toast.makeText(this, "No Match", Toast.LENGTH_LONG).show();
        } else {
            result.moveToFirst();
            d = result.getString(3);

        }

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                i.putExtra("email", email);
                //send due date
                i.putExtra("due",d);
                startActivity(i);
            }
        });

        community.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), QA_Community.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        appointments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), appointment.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), account.class);
                i.putExtra("email", email);
                startActivity(i);
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);

    }
    @Override
    public  boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){

            case R.id.action_add_task:
                final EditText taskEditText= new EditText(this);
                AlertDialog alertDialog= new AlertDialog.Builder(this)
                        .setTitle("Add new appointment")
                        .setMessage(" ")
                        .setView(taskEditText)
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String task=String.valueOf(taskEditText.getText());
                                SQLiteDatabase db= taskHelper.getWritableDatabase();
                                ContentValues values= new ContentValues();
                                values.put(Task.taskEntry.COL_TASK_TITLE,task);
                                db.insertWithOnConflict(Task.taskEntry.TABLE,null,values,SQLiteDatabase.CONFLICT_REPLACE);
                                db.close();
                                updateUI();
                            }
                        })
                        .setNegativeButton("Cancel",null)
                        .create();
                alertDialog.show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI(){

        ArrayList<String> taskList =new ArrayList<>();
        SQLiteDatabase db= taskHelper.getReadableDatabase();
        Cursor cursor= db.query(Task.taskEntry.TABLE, new String[]{Task.taskEntry._ID, Task.taskEntry.COL_TASK_TITLE},
                null,null,null,null,null);
        while(cursor.moveToNext()){

            int index=cursor.getColumnIndex(Task.taskEntry.COL_TASK_TITLE);
            taskList.add(cursor.getString(index));
        }

        if(mAdapter==null){
            mAdapter=new ArrayAdapter<>(this,R.layout.item_todo,R.id.task_title,taskList);
            TaskListView.setAdapter(mAdapter);
        }
        else{
            mAdapter.clear();
            mAdapter.addAll(taskList);
            mAdapter.notifyDataSetChanged();
        }
        cursor.close();
        db.close();

    }

    public void deleteTask(View view){

        View parent = (View) view.getParent();
        TextView taskTextView = (TextView) parent.findViewById(R.id.task_title);
        String task = String.valueOf(taskTextView.getText());
        SQLiteDatabase db = taskHelper.getWritableDatabase();
        db.delete(Task.taskEntry.TABLE, Task.taskEntry.COL_TASK_TITLE + "= ?",new String[]{task});
        db.close();
        updateUI();

    }


}
